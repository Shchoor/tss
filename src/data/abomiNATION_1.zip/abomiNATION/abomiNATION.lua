-- Abomi-NATION addon
--
-- This addon adds the Guild note of your mouseover'd target and also their guild rank to your default
-- tooltip to make it easier to identify each other without the need to constantly observe the different
-- accents, level & class from the Guild tab
--
--      Project: Abomi-NATION
--      LastUpdated: 02/12/2020
--      Authors: Vhaen
version = "2.2.0"

abomiNATION = LibStub("AceAddon-3.0"):NewAddon("abomiNATION")
AceGUI = LibStub("AceGUI-3.0")
 
TSSPath = "Interface\\AddOns\\abomiNATION\\Textures\\TSS.blp"
discord = "https://discord.gg/CcAEdve"
youtube = "https://www.youtube.com/c/TheScarletScourge"

-------------------------------------------------------------------------------------------------
--Colour Strings
-------------------------------------------------------------------------------------------------

red = "|CFFFF0303"
green = "|CFF20C000"
blue = "|CFF0042FF"
colEnd = "|r"

-------------------------------------------------------------------------------------------------
-- Slash commands for future use for config.
-------------------------------------------------------------------------------------------------
local function abomiNATIONCommands(msg, editbox)
    --targetName = UnitName("target")
    targetName =GetUnitName("target",true)
    if msg == "discord" then
        SendChatMessage(
            "You are invited to join The Scarlet Scourge on discord: [" .. discord .. "]",
            "WHISPER",
            "Common",
            targetName
        )
    else
        if (msg == "youtube" or msg == "yt") then
            SendChatMessage(
                "Check out The Scarlet Scourge on YouTube : [" .. youtube .. "]",
                "WHISPER",
                "Common",
                targetName
            )
        else
            if msg == "ad1" then
                local s =
                    [[ [The Scarlet Scourge] are recruiting more Abominations to join the ranks! Great Leveling Community,  M+, Arena,SL Raiding / RBGs, and of course wPVP > Check out this Video of us @ "Asmongold reacts to The Scarlet Scourge" /w for me info]]
                local index = GetChannelName("Trade")
                if (index ~= nil) then
                    SendChatMessage(s, "CHANNEL", nil, index)
                end
            else
                if msg == "ad2" then
                    local s =
                        [[ [The Scarlet Scourge] Undead only guild named Abomination. 300+ Discord Members, 480+ Characters in-game. Infamous for our wPvP! Raiding & RBGs in SL, M+, BGs, Great leveling Community! Youtube @ Asmongold reacts to Scarlet Scourge]]
                    local index = GetChannelName("Trade")
                    if (index ~= nil) then
                        SendChatMessage(s, "CHANNEL", nil, index)
                    end
                else
                    if msg == "ad3" then
                        local s =
                            [[ [The Scarlet Scourge] 300+ Discord Members/480+ Characters in-game! Undead only & Abomination named Guild! Infamous for our wPvP! Unique uniforms for events! Raiding & RBGs in SL! Leveling community! BGs, M+, Dungeons!Youtube @ [The Scarlet Scourge] ]]
                        local index = GetChannelName("Trade")
                        if (index ~= nil) then
                            SendChatMessage(s, "CHANNEL", nil, index)
                        end
                    else
                        if msg == "ad4" then
                            local s =
                                [[Looking for something new? As well as something fun to do during the wait for ShadowLands? [The Scarlet Scourge] Infamous for our world PvP Videos! @ " Asmongold reacts to Scarlet Scourge " - M+, Dungeons, Leveling, Raiding & RBGs in SL!]]
                            local index = GetChannelName("Trade")
                            if (index ~= nil) then
                                SendChatMessage(s, "CHANNEL", nil, index)
                            end
                        else
                           if msg == "ad5" then
                               local s =
                                   [[Looking for a unique twist of a guild? Well we're exactly that! Infamous for our wPvP and Multiboxer appearance! [The Scarlet Scourge] > Undead & Abomination named only guild @ youtube "The Scarlet Scourge"]]
                               local index = GetChannelName("Trade")
                               if (index ~= nil) then
                                   SendChatMessage(s, "CHANNEL", nil, index)
                               end
                           else                               
                               local options = AceGUI:Create("Frame")
                               options:SetTitle(
                                   [[|CFFFF0303
_____________________

THE SCARLET SCOURGE
_____________________


            |r ]]
                                )
                                options:SetHeight(500)
                                options:SetWidth(400)
                                options:EnableResize(false)
                                options:SetLayout("Flow")
    
                                local d2 = AceGUI:Create("Icon")
                                d2:SetImage(TSSPath)
                                d2:SetImageSize(256, 256)
                                d2:SetFullWidth(true)
                                d2:SetLabel("|CFFFF0303abomiNATION - Version: " .. version .. " - Authors: Vhaen|r")
                                d2:SetCallback(
                                    "OnClick",
                                    function()
                                        GuildInvite(targetName)
                                    end
                                )
                                options:AddChild(d2)
    
                                local ytBox = AceGUI:Create("EditBox")
                                ytBox:SetLabel("|CFFFF0303YouTube|r")
                                ytBox:SetWidth(350)
                                ytBox:SetText(youtube)
                                options:AddChild(ytBox)
    
                                local ytdesc = AceGUI:Create("Label")
                                ytdesc:SetText("Send this link to your target anytime with '/abom yt' or '/abom youtube'")
                                ytdesc:SetFullWidth(true)
                                options:AddChild(ytdesc)
    
                                local discordBox = AceGUI:Create("EditBox")
                                discordBox:SetLabel("|CFFFF0303Discord|r")
                                discordBox:SetWidth(350)
                                discordBox:SetText(discord)
                                options:AddChild(discordBox)
    
                                local ddesc = AceGUI:Create("Label")
                                ddesc:SetText("Send this link to your target anytime with '/abom discord'")
                                ddesc:SetFullWidth(true)
                                options:AddChild(ddesc)
    
                            end
                        end
                    end
                end
            end
        end
    end
end

SLASH_ABOM1 = "/abom"
SlashCmdList["ABOM"] = abomiNATIONCommands


local numMembers = GetNumGuildMembers()

-------------------------------------------------------------------------------------------------
-- Mouseover
-------------------------------------------------------------------------------------------------
local mframe = CreateFrame("FRAME")
GameTooltip:HookScript(
    "OnTooltipSetUnit",
    function(tooltip)
	numMembers = GetNumGuildMembers()
        for i = 1, numMembers do
            local name,
                rank,
                rankIndex,
                level,
                class,
                zone,
                publicnote,
                officernote,
                online,
                status,
                classFileName,
                achPts,
                achRank,
                isMobile,
                canSoR = GetGuildRosterInfo(i)
            local mouseoverName = UnitName("mouseover")

            if (mouseoverName ~= nil) then
                local fullName = mouseoverName .. "-" .. "Ravencrest"
				
                if (name == fullName and publicnote ~= "") then
                    GameTooltip:AddLine("Mouseover: "..publicnote .. "  |  " .. rank, 0.77, 0.12, 0.23, 1)
					GameTooltip:Show()
                end
            end
        end
    end
)

-------------------------------------------------------------------------------------------------
-- Target
-------------------------------------------------------------------------------------------------
local tframe = CreateFrame("FRAME")
GameTooltip:HookScript(
    "OnTooltipSetUnit",
    function(tooltip)
	numMembers = GetNumGuildMembers()
        for i = 1, numMembers do
            local name,
                rank,
                rankIndex,
                level,
                class,
                zone,
                publicnote,
                officernote,
                online,
                status,
                classFileName,
                achPts,
                achRank,
                isMobile,
                canSoR = GetGuildRosterInfo(i)
            local targetName = UnitName("target")

            if (targetName ~= nil) then
                local fullName = targetName .. "-" .. "Ravencrest"
				
                if (name == fullName and publicnote ~= "") then
                    GameTooltip:AddLine("My target: ".. publicnote .. "  |  " .. rank, 1,0.49,0.04, 1)
					GameTooltip:Show()
                end
            end
        end
    end
)



-------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------


function Print(text)
	text = tostring( text )
	
	local prefix = "|CFFFF0303[abomiNATION]|r "
	print( prefix .. text )
end


-------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------
