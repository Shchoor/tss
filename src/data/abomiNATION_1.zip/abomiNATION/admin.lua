-- Abomi-NATION addon
--
-- This addon adds the Guild note of your mouseover'd target and also their guild rank to your default
-- tooltip to make it easier to identify each other without the need to constantly observe the different
-- accents, level & class from the Guild tab
--
--      Project: Abomi-NATION
--      Authors: Vhaen

-- This function does the following: If you target someone in the guild and they have no note set, it
-- will request them to set it.

local frame = CreateFrame("FRAME")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
local numMembers = GetNumGuildMembers()

local function eventHandler(self, event, ...)
    for index = 1, numMembers do
        local name, _, _, _, _, _, note, _, _, _, _, _, _, _, _, _, Info = GetGuildRosterInfo(index)

        local mouseoverName = UnitName("target")
        
        if(mouseoverName ~= nill) then  local fullName = mouseoverName .. "-" .. "Ravencrest"

        if (name == fullName and note == "") then
            --print("no note")
            SendChatMessage(
                "[abomiNATION automated whisper]: would like to remind you to set your guild note to your name.",
                "WHISPER",
                "Common",
                fullName
            )
        end
        end
    end
end

frame:SetScript("OnEvent", eventHandler)
